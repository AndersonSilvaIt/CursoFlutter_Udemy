class AppRoutes {
  static const String placeForm = '/place-form';
}
