class Constants {
  static const userFavoritesUrl =
      'https://shop-cod3r-c70a4-default-rtdb.firebaseio.com/userFavorites';
  static const productBaseUrl =
      'https://shop-cod3r-c70a4-default-rtdb.firebaseio.com/products';
  static const orderBaseUrl =
      'https://shop-cod3r-c70a4-default-rtdb.firebaseio.com/orders';
  static const webApiKey = 'AIzaSyAOB9uer_xxRprUZnoZSqeK3oenNmingOc';
}
